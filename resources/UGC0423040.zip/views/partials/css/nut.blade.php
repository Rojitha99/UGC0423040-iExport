<style>
.search-container {
      max-width: 700px;
      margin-top: -70px ;
      margin-left: 450px;
      margin-bottom: 40px;
      position: relative;
      background: white;
      border: #cc7116;
      border-radius: 40px;
      padding: 5px;
      box-shadow: 0 2px 5px #B86B46;
    }
</style>